# Harvester - Support Boot EFI/UEFI

Cette archive contient tous les fichiers essentiels pour créer une image raw Harvester avec boot EFI/UEFI au lieu du boot BIOS legacy.

## 📦 Contenu de l'archive

- **`build-efi-raw.sh`** - Script automatique pour créer l'image raw EFI
- **`patch-package-harvester-os.patch`** - Patch à appliquer sur `scripts/package-harvester-os`
- **`GUIDE_CREATION_IMAGE_EFI.md`** - Guide complet d'utilisation
- **`GUIDE_RAPIDE_EFI.md`** - Guide rapide (3 étapes)
- **`DIFF_EFI_CHANGES.md`** - Documentation des changements (référence)

## 🚀 Installation Rapide

### Étape 1 : Appliquer le patch

```bash
cd /path/to/harvester-installer
git apply patch-package-harvester-os.patch
```

### Étape 2 : Installer les prérequis

```bash
# openSUSE/SLES
sudo zypper install qemu qemu-ovmf-x86_64

# Debian/Ubuntu
sudo apt-get install qemu-system-x86 ovmf

# Fedora/RHEL
sudo dnf install qemu-system-x86 edk2-ovmf
```

### Étape 3 : Construire l'ISO (si pas déjà fait)

```bash
cd /path/to/harvester-installer
make
```

### Étape 4 : Créer l'image raw EFI

```bash
# Copier le script dans le répertoire
cp build-efi-raw.sh /path/to/harvester-installer/
chmod +x build-efi-raw.sh

# Exécuter
./build-efi-raw.sh
```

## 📖 Documentation

- **Guide rapide :** Lisez `GUIDE_RAPIDE_EFI.md` pour une utilisation en 3 étapes
- **Guide complet :** Lisez `GUIDE_CREATION_IMAGE_EFI.md` pour tous les détails
- **Changements :** Consultez `DIFF_EFI_CHANGES.md` pour comprendre les modifications

## ✅ Vérification

Après création, vérifiez que l'image utilise bien EFI :

```bash
sudo parted dist/artifacts/harvester-*-amd64.raw print | grep efi
```

Vous devriez voir une partition avec :
- File system: `fat16`
- Name: `efi`
- Flags: `boot, esp`

## 🔧 Alternative : Utiliser BUILD_QCOW

Si vous préférez utiliser le système de build intégré :

```bash
BUILD_QCOW=true make
```

Le code modifié dans `scripts/package-harvester-os` sera utilisé automatiquement.

## 📝 Notes

- L'image raw fait 250GB (mais compressée à ~20GB)
- Le processus prend 10-20 minutes
- Assurez-vous d'avoir au moins 8GB de RAM disponible
- KVM doit être activé et accessible

## 🆘 Support

En cas de problème, consultez la section "Dépannage" dans `GUIDE_CREATION_IMAGE_EFI.md`.
